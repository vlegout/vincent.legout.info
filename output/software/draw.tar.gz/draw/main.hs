
import qualified Diagram

main :: IO ()
main = do
     Diagram.run