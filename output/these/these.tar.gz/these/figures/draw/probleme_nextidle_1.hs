
height_sched = 30.0
tot_length = 12.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 0.0
margin_x_left = 20.0

print_x_scale = True

n_tasks = 3

arrows = [ ]

diagrams = [ Diagram "" "t" 1 "π<sub>1</sub>"
           , Diagram "" "t" 1 "π<sub>2</sub>"
           ]

execs = [ Exec 0 1 0 "τ<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 0 2 1 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 2 3 0 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 3 4 0 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 5 6 0 "τ<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 6 7 0 "τ<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 4 6 1 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 6 8 1 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 8 9 0 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 9 10 0 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 11 12 0 "τ<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 10 12 1 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 8 11 2 "τ<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        ]

vlines = [ ]

texts = [ ]
