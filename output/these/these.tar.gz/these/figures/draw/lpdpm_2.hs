
height_sched = 30.0
tot_length = 12.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 15.0
margin_x_left = 25.0

print_x_scale = True

n_tasks = 4

arrows = [ ]

diagrams = [ Diagram "" "t" 1 "π<sub>1</sub>"
           , Diagram "" "t" 1 "π<sub>2</sub>"
           ]

execs = [ Exec 0 2 3 "τ<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 2 4 0 "τ'" 1 0 SizeTiny 1.0 1.0
        , Exec 0 2.4 2 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 2.4 3.2 3 "τ<sub>3</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 3.2 4 1 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 4 5.2 3 "τ<sub>3</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 5.2 6 1 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 4 6 2 "τ<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 6 8 0 "τ'" 2 0 SizeTiny 1.0 1.0
        , Exec 6 7.6 3 "τ<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 7.6 8 2 "τ<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 8 9.6 2 "τ<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 9.6 12 0 "τ'" 1 0 SizeTiny 1.0 1.0
        , Exec 8 10.4 3 "τ<sub>3</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 10.4 11.2 2 "τ<sub>2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 11.2 12 1 "τ<sub>1</sub>" 2 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 4
         , VLine 6
         , VLine 8
         , VLine 12
         ]

texts = [ Text 2 "I<sub>1</sub>" SizeTiny
        , Text 5 "I<sub>2</sub>" SizeTiny
        , Text 7 "I<sub>3</sub>" SizeTiny
        , Text 10 "I<sub>4</sub>" SizeTiny
        ]
