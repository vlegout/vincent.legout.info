
height_sched = 30.0
tot_length = 12.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 10.0
margin_x_left = 25.0

print_x_scale = True

n_tasks = 3

arrows = [ ]

diagrams = [ Diagram "" "t" 1 "(3)"]

execs = [ Exec 2 4 1 "τ'" 1 0 SizeTiny 1.0 1.0
        , Exec 7 8 1 "τ'" 1 0 SizeTiny 1.0 1.0
        , Exec 11 12 0 "τ'" 1 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 4
         , VLine 8
         , VLine 12
         ]

texts = [ ]
