
height_sched = 30.0
tot_length = 12.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 15.0
margin_x_left = 25.0

print_x_scale = True

n_tasks = 8

arrows = [ Arrow 4 1
       	 , Arrow 8 1
	 , Arrow 4 2
	 , Arrow 8 2
	 , Arrow 6 3
	 ]

diagrams = [ Diagram "" "t" 1 "τ<sub>1</sub>"
           , Diagram "" "t" 1 "τ<sub>2</sub>"
           , Diagram "" "t" 1 "τ<sub>3</sub>"
           ]

execs = [ Exec 0 4 0 "j<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 4 8 1 "j<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 8 12 2 "j<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 0 4 3 "j<sub>4</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 4 8 4 "j<sub>5</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 8 12 5 "j<sub>6</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 0 6 6 "j<sub>7</sub>" 3 0 SizeTiny 1.0 1.0
        , Exec 6 12 7 "j<sub>8</sub>" 3 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 4
         , VLine 6
         , VLine 8
         , VLine 12
         ]

texts = [ Text 2 "I<sub>1</sub>" SizeTiny
        , Text 5 "I<sub>2</sub>" SizeTiny
        , Text 7 "I<sub>3</sub>" SizeTiny
        , Text 10 "I<sub>4</sub>" SizeTiny
        ]
