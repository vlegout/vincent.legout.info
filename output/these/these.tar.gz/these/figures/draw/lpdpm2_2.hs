
height_sched = 30.0
tot_length = 24.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 15.0
margin_x_left = 25.0

print_x_scale = True

n_tasks = 5

arrows = [ ]

diagrams = [ Diagram "" "t" 1 "π<sub>1</sub>"
           , Diagram "" "t" 1 "π<sub>2</sub>"
           ]

execs = [ Exec 4 5.5 0 "" 1 0 SizeTiny 1.0 1.0
        , Exec 5.5 6 4 "" 1 0 SizeTiny 1.0 1.0
        , Exec 6 11.5 0 "" 1 0 SizeTiny 1.0 1.0
        , Exec 11.5 12 1 "" 1 0 SizeTiny 1.0 1.0
        , Exec 12 15.5 0 "" 1 0 SizeTiny 1.0 1.0
        , Exec 15.5 16 2 "" 1 0 SizeTiny 1.0 1.0
        , Exec 20.5 21.5 4 "" 1 0 SizeTiny 1.0 1.0
        , Exec 21.5 22.5 1 "" 1 0 SizeTiny 1.0 1.0
        , Exec 22.5 23 2 "" 1 0 SizeTiny 1.0 1.0
        , Exec 23 24 3 "" 1 0 SizeTiny 1.0 1.0

        , Exec 0 3.5 0 "" 2 0 SizeTiny 1.0 1.0
        , Exec 3.5 4 4 "" 2 0 SizeTiny 1.0 1.0
        , Exec 4 5 1 "" 2 0 SizeTiny 1.0 1.0
        , Exec 5 7 2 "" 2 0 SizeTiny 1.0 1.0
        , Exec 7 8 3 "" 2 0 SizeTiny 1.0 1.0
        , Exec 8 8.5 1 "" 2 0 SizeTiny 1.0 1.0
        , Exec 13 14 1 "" 2 0 SizeTiny 1.0 1.0
        , Exec 14 15 3 "" 2 0 SizeTiny 1.0 1.0
        , Exec 15 16 4 "" 2 0 SizeTiny 1.0 1.0
        , Exec 16 17.5 0 "" 2 0 SizeTiny 1.0 1.0
        , Exec 17.5 18 2 "" 2 0 SizeTiny 1.0 1.0
        , Exec 18 23.5 0 "" 2 0 SizeTiny 1.0 1.0
        , Exec 23.5 24 2 "" 2 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 4
         , VLine 6
         , VLine 8
         , VLine 12
         , VLine 16
         , VLine 18
         , VLine 20
         , VLine 24
         ]

texts = [ Text 2 "I<sub>1</sub>" SizeTiny
        , Text 5 "I<sub>2</sub>" SizeTiny
        , Text 7 "I<sub>3</sub>" SizeTiny
        , Text 10 "I<sub>4</sub>" SizeTiny
        , Text 14 "I<sub>5</sub>" SizeTiny
        , Text 17 "I<sub>6</sub>" SizeTiny
        , Text 19 "I<sub>7</sub>" SizeTiny
        , Text 22 "I<sub>8</sub>" SizeTiny
        ]
