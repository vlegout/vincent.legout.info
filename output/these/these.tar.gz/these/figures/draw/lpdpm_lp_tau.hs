
height_sched = 30.0
tot_length = 18.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 14.0
margin_x_left = 10.0

print_x_scale = True

n_tasks = 3

arrows = [ ]

diagrams = [ Diagram "" "t" 1 ""
           ]

execs = [ Exec 2 3 1 "e<sub>1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 3 4.5 1 "b<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 4.5 6 1 "e<sub>2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 6 7 1 "b<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 8 9 1 "e<sub>3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 9 10 1 "b<sub>4</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 11 12 1 "e<sub>4</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 15 16 1 "b<sub>6</sub>" 1 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 0
         , VLine 3
         , VLine 6
         , VLine 9
         , VLine 12
         , VLine 15
         , VLine 18
         ]

texts = [ Text 1.5 "I<sub>1</sub>" SizeTiny
        , Text 4.5 "I<sub>2</sub>" SizeTiny
        , Text 7.5 "I<sub>3</sub>" SizeTiny
        , Text 10.5 "I<sub>4</sub>" SizeTiny
        , Text 13.5 "I<sub>5</sub>" SizeTiny
        , Text 16.5 "I<sub>6</sub>" SizeTiny
        ]
