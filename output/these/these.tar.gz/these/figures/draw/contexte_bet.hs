
height_sched = 60.0
tot_length = 11.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 0.0
margin_x_left = 20.0

print_x_scale = True

n_tasks = 3

arrows = [ Arrow 10 1
         ]

diagrams = [ Diagram "" "t" 1 "" ]

execs = [ Exec 0 4 0 "" 1 0 SizeTiny 1.0 1.0 ]

vlines = [ ]

texts = [ ]
