
height_sched = 30.0
tot_length = 12.0
unit_width = 20.0

margin_bottom = 10.0
margin_top = 15.0
margin_x_left = 25.0

print_x_scale = True

n_tasks = 8

arrows = [ Arrow 4 1
       	 , Arrow 8 1
	 , Arrow 4 2
	 , Arrow 8 2
	 , Arrow 6 3
	 ]

diagrams = [ Diagram "" "t" 1 "τ<sub>1</sub>"
           , Diagram "" "t" 1 "τ<sub>2</sub>"
           , Diagram "" "t" 1 "τ<sub>3</sub>"
           ]

execs = [ Exec 0 4 0 "w<sub>1,1</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 4 6 1 "w<sub>2,2</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 6 8 1 "w<sub>2,3</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 8 12 2 "w<sub>3,4</sub>" 1 0 SizeTiny 1.0 1.0
        , Exec 0 4 3 "w<sub>4,1</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 4 6 4 "w<sub>5,2</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 6 8 4 "w<sub>5,3</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 8 12 5 "w<sub>6,4</sub>" 2 0 SizeTiny 1.0 1.0
        , Exec 0 4 6 "w<sub>7,1</sub>" 3 0 SizeTiny 1.0 1.0
        , Exec 4 6 6 "w<sub>7,2</sub>" 3 0 SizeTiny 1.0 1.0
        , Exec 6 8 7 "w<sub>8,3</sub>" 3 0 SizeTiny 1.0 1.0
        , Exec 8 12 7 "w<sub>8,4</sub>" 3 0 SizeTiny 1.0 1.0
        ]

vlines = [ VLine 4
         , VLine 6
         , VLine 8
         , VLine 12
         ]

texts = [ Text 2 "I<sub>1</sub>" SizeTiny
        , Text 5 "I<sub>2</sub>" SizeTiny
        , Text 7 "I<sub>3</sub>" SizeTiny
        , Text 10 "I<sub>4</sub>" SizeTiny
        ]
