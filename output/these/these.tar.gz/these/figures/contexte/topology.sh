#!/bin/sh

rm topology.svg

lstopo --no-legend --no-io --of svg --input topology.xml > topology.svg

# inkscape topology.svg
