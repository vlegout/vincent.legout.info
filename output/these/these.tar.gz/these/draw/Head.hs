
module Tasks
( Arrow (..)
, arrows
, Diagram(..)
, diagrams
, Exec(..)
, execs
, height_sched
, margin_bottom
, margin_top
, margin_x_left
, n_tasks
, print_x_scale
, Text(..)
, texts
, tot_length
, unit_width
, VLine(..)
, vlines
) where

import Graphics.Rendering.Pango.Markup
import Graphics.Rendering.Pango.Enums

data Arrow = Arrow { x_arrow :: Double
                   , x_diagram :: Double
		   }

data Diagram = Diagram { title :: Markup
                       , x_axis :: String
                       , x_grid :: Double
                       , y_axis :: String
                       }

data Exec = Exec { start :: Double
                 , end :: Double
                 , color :: Int
                 , desc :: Markup
                 , diagram :: Double
                 , kind :: Int
                 , size :: Size
                 , execHeight :: Double
                 , alpha :: Double
                 }

data VLine = VLine { linex :: Double }

data Text = Text { textAbsc :: Double
                 , textStr :: String
                 , textSize :: Size
                 }
